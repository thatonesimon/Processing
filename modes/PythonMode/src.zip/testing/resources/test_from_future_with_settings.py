from __future__ import division

def setup():
    size(20, 20)

def draw():
    print 'OK'
    exit()